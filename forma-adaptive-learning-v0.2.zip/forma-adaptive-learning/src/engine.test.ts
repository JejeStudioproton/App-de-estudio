import { describe, expect, it } from "vitest";
import { createConcept, dueCount, empty, normalizeData, recommend, scheduleReview } from "./engine";

const now = new Date("2026-01-10T12:00:00.000Z");
const subject = { id: "s1", name: "Biología", color: "#dfece5", createdAt: now.toISOString() };
const concept = createConcept({ subjectId: "s1", title: "Fotosíntesis", explanation: "Proceso por el que las plantas convierten la luz en energía química." }, now);

describe("learning engine", () => {
  it("normalizes malformed or missing data without crashing", () => {
    expect(normalizeData(null)).toEqual(empty());
    expect(normalizeData({ subjects: "bad", concepts: [], responses: [] }).subjects).toEqual([]);
  });
  it("schedules a remembered concept further into the future", () => {
    const first = scheduleReview(concept, "remembered", now);
    const second = scheduleReview(first, "remembered", now);
    expect(first.intervalDays).toBe(1);
    expect(second.intervalDays).toBe(2);
    expect(second.mastery).toBeGreaterThan(first.mastery);
  });
  it("resets a forgotten concept to a short review interval", () => {
    const mature = { ...concept, mastery: 0.8, intervalDays: 20 };
    const result = scheduleReview(mature, "forgotten", now);
    expect(result.intervalDays).toBe(1);
    expect(result.mastery).toBeCloseTo(0.68);
  });
  it("prioritizes due concepts before future reviews", () => {
    const future = { ...concept, id: "future", nextReviewAt: "2026-02-01T00:00:00.000Z", mastery: 0.1 };
    const due = { ...concept, id: "due", nextReviewAt: "2026-01-09T00:00:00.000Z", mastery: 0.8 };
    expect(recommend({ ...empty(), subjects: [subject], concepts: [future, due] }, undefined, now)?.id).toBe("due");
  });
  it("counts due concepts against the supplied clock", () => {
    const data = { ...empty(), subjects: [subject], concepts: [concept, { ...concept, id: "future", nextReviewAt: "2026-02-01T00:00:00.000Z" }] };
    expect(dueCount(data, now)).toBe(1);
  });
});
