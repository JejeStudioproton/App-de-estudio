/// <reference types="vite/client" />
import * as pdfjsLib from "pdfjs-dist";
import workerUrl from "pdfjs-dist/build/pdf.worker.min.mjs?url";
import * as mammoth from "mammoth";

pdfjsLib.GlobalWorkerOptions.workerSrc = workerUrl;

export async function extractText(file: File): Promise<string> {
  const extension = file.name.toLowerCase().split(".").pop();
  if (extension === "txt" || extension === "md") return (await file.text()).trim();
  if (extension === "docx") {
    const result = await mammoth.extractRawText({ arrayBuffer: await file.arrayBuffer() });
    return result.value.trim();
  }
  if (extension === "pdf") {
    const document = await pdfjsLib.getDocument({ data: await file.arrayBuffer() }).promise;
    const pages: string[] = [];
    for (let pageNumber = 1; pageNumber <= document.numPages; pageNumber++) {
      const page = await document.getPage(pageNumber);
      const content = await page.getTextContent();
      pages.push(content.items.map(item => "str" in item ? item.str : "").join(" "));
    }
    const result = pages.join("\n\n").trim();
    if (!result) throw new Error("El PDF no contiene texto seleccionable. Los documentos escaneados requieren OCR, que no está incluido.");
    return result;
  }
  throw new Error("Formato no compatible. Usa PDF con texto seleccionable, DOCX, TXT o Markdown.");
}
