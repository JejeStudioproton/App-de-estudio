import { ChangeEvent, useEffect, useMemo, useState } from "react";
import { BookOpen, Brain, Check, ChevronRight, FileText, Home, Layers3, Plus, Search, ShieldCheck, Target, Trash2, Upload, X, Download, CalendarDays } from "lucide-react";
import { createConcept, dueCount, empty, exportData, load, normalizeData, recommend, save, scheduleReview, type Concept, type Data, type Evidence, type PracticeMode, type Subject } from "./engine";
import { extractText } from "./importer";

const colors = ["#dfece5", "#e9e4f2", "#f1e8d6", "#dfe9f2", "#f0e1df"];
const modeLabels: Record<PracticeMode, string> = { recall: "Recordar", explain: "Explicar", apply: "Aplicar" };
const evidenceLabels: Record<Evidence, string> = { remembered: "Lo recordaba", partial: "Recordaba una parte", forgotten: "No lo recordaba", skipped: "No he respondido" };

export default function App() {
  const [data, setData] = useState<Data>(() => load());
  const [page, setPage] = useState("home");
  const [subjectId, setSubjectId] = useState("");
  const [modal, setModal] = useState("");
  const [name, setName] = useState("");
  const [examDate, setExamDate] = useState("");
  const [title, setTitle] = useState("");
  const [explanation, setExplanation] = useState("");
  const [source, setSource] = useState("");
  const [query, setQuery] = useState("");
  const [active, setActive] = useState<Concept | undefined>();
  const [mode, setMode] = useState<PracticeMode>("recall");
  const [answer, setAnswer] = useState("");
  const [confidence, setConfidence] = useState(3);
  const [revealed, setRevealed] = useState(false);
  const [feedback, setFeedback] = useState<Evidence | "">("");
  const [importMessage, setImportMessage] = useState("");

  useEffect(() => { try { save(data); } catch { /* browser storage may be disabled or full */ } }, [data]);
  const current = data.subjects.find(s => s.id === subjectId);
  const concepts = data.concepts.filter(c => c.subjectId === subjectId);
  const next = recommend(data);
  const due = dueCount(data);
  const avg = data.concepts.length ? Math.round(data.concepts.reduce((sum, c) => sum + c.mastery, 0) / data.concepts.length * 100) : 0;
  const filtered = useMemo(() => data.subjects.filter(s => s.name.toLocaleLowerCase("es").includes(query.toLocaleLowerCase("es"))), [data.subjects, query]);

  function addSubject() {
    if (!name.trim()) return;
    const s: Subject = { id: crypto.randomUUID(), name: name.trim(), color: colors[data.subjects.length % colors.length], createdAt: new Date().toISOString(), ...(examDate ? { examDate } : {}) };
    setData(d => ({ ...d, subjects: [...d.subjects, s] })); setSubjectId(s.id); setName(""); setExamDate(""); setModal(""); setPage("subject");
  }
  function addConcept() {
    if (!subjectId || !title.trim() || !explanation.trim()) return;
    setData(d => ({ ...d, concepts: [...d.concepts, createConcept({ subjectId, title: title.trim(), explanation: explanation.trim(), source: source.trim() || undefined })] }));
    setTitle(""); setExplanation(""); setSource(""); setModal("");
  }
  function begin(c = next, nextMode: PracticeMode = "recall") {
    if (!c) return; setActive(c); setMode(nextMode); setAnswer(""); setConfidence(3); setRevealed(false); setFeedback(""); setPage("study");
  }
  function record(evidence: Evidence) {
    if (!active || feedback) return;
    const now = new Date();
    const updated = scheduleReview(active, evidence, now);
    setData(d => ({ ...d, concepts: d.concepts.map(c => c.id === active.id ? updated : c), responses: [...d.responses, { id: crypto.randomUUID(), conceptId: active.id, subjectId: active.subjectId, mode, answer: answer.trim(), evidence, confidence, createdAt: now.toISOString(), dueBefore: active.nextReviewAt }] }));
    setFeedback(evidence);
  }
  async function importFile(event: ChangeEvent<HTMLInputElement>) {
    const file = event.target.files?.[0]; if (!file || !subjectId) return;
    setImportMessage("Leyendo documento…");
    try {
      const text = await extractText(file);
      const paragraphs = text.split(/\n{1,}|(?<=[.!?])\s{2,}/).map(p => p.trim()).filter(p => p.length >= 45).slice(0, 80);
      if (!paragraphs.length) throw new Error("No he encontrado texto suficiente para proponer conceptos.");
      setTitle("Importación: " + file.name.replace(/\.[^.]+$/, ""));
      setExplanation(text.slice(0, 5000));
      setSource(`Documento original: ${file.name}. Revisa y confirma el texto extraído antes de guardar.`);
      setImportMessage(`Texto extraído (${text.length.toLocaleString("es-ES")} caracteres). He preparado un borrador editable de hasta 5.000 caracteres; revisa el documento original y confirma el contenido antes de guardarlo.`);
      setModal("concept");
    } catch (error) { setImportMessage(error instanceof Error ? error.message : "No se ha podido leer el documento."); }
    event.target.value = "";
  }
  function downloadBackup() {
    const blob = new Blob([exportData(data)], { type: "application/json" }); const url = URL.createObjectURL(blob);
    const a = document.createElement("a"); a.href = url; a.download = `forma-respaldo-${new Date().toISOString().slice(0, 10)}.json`; a.click(); URL.revokeObjectURL(url);
  }
  async function restoreBackup(event: ChangeEvent<HTMLInputElement>) {
    const file = event.target.files?.[0]; if (!file) return;
    try { const restored = normalizeData(JSON.parse(await file.text())); if (!confirm(`El archivo contiene ${restored.subjects.length} materias y ${restored.concepts.length} conceptos. ¿Reemplazar los datos actuales?`)) return; setData(restored); setPage("home"); alert("Respaldo restaurado en este navegador."); }
    catch { alert("El archivo no es un respaldo válido de la aplicación."); }
    event.target.value = "";
  }
  function deleteConcept(c: Concept) {
    if (!confirm(`¿Eliminar «${c.title}» y su historial de respuestas?`)) return;
    setData(d => ({ ...d, concepts: d.concepts.filter(x => x.id !== c.id), responses: d.responses.filter(r => r.conceptId !== c.id) }));
  }

  return <div className="shell">
    <aside className="sidebar">
      <div className="brand"><div className="mark"><i/><i/><i/></div><div><b>FORMA</b><small>APRENDIZAJE PERSONAL</small></div></div>
      <label className="label">TU ESPACIO</label>
      <button className={page === "home" ? "nav active" : "nav"} onClick={() => setPage("home")}><Home/>Inicio</button>
      <button className={["subjects", "subject"].includes(page) ? "nav active" : "nav"} onClick={() => setPage("subjects")}><BookOpen/>Materias <span>{data.subjects.length}</span></button>
      <button className={page === "insights" ? "nav active" : "nav"} onClick={() => setPage("insights")}><Brain/>Cómo aprendo</button>
      <div className="line"/><label className="label">MATERIAS</label>
      {data.subjects.slice(0, 7).map(s => <button className="subject-link" key={s.id} onClick={() => { setSubjectId(s.id); setPage("subject"); }}><i style={{ background: s.color }}/>{s.name}</button>)}
      <button className="subject-link muted" onClick={() => setModal("subject")}><Plus/>Añadir materia</button>
      <div className="bottom-note"><ShieldCheck/><span>Datos guardados en este navegador. Exporta un respaldo con regularidad.</span></div>
    </aside>
    <main>
      <header><span>Espacio personal　/　<b>{page === "home" ? "Inicio" : page === "subjects" ? "Materias" : page === "subject" ? current?.name : page === "study" ? "Sesión" : page === "insights" ? "Cómo aprendo" : "Datos"}</b></span><span className="local">● Datos locales</span></header>
      {page === "home" && <section className="page">
        <div className="hero"><div><label className="label">TU PUNTO DE PARTIDA</label><h1>Aprender mejor,<br/><em>no estudiar más.</em></h1><p>Practica, comprueba lo que recuerdas y programa repasos según tu propio resultado.</p></div><div className="orb"><Brain/></div></div>
        <div className="section-title"><div><h2>Qué estudiar ahora</h2><p>Se priorizan los repasos vencidos y los conceptos con menor dominio orientativo.</p></div></div>
        {next ? <div className="recommend"><div className="tile"><Target/></div><div className="grow"><label className="label">SIGUIENTE PASO</label><h3>{next.title}</h3><p>{data.subjects.find(s => s.id === next.subjectId)?.name} · Dominio orientativo {Math.round(next.mastery * 100)}%</p><small>{Date.parse(next.nextReviewAt) <= Date.now() ? "Repaso pendiente" : `Próximo repaso: ${new Date(next.nextReviewAt).toLocaleDateString("es-ES")}`}</small></div><button className="primary" onClick={() => begin(next)}>Empezar <ChevronRight/></button></div> : <div className="empty-recommend"><Target/><div className="grow"><h3>Tu siguiente paso empieza aquí</h3><p>Añade una materia y un concepto para preparar una sesión.</p></div><button className="secondary" onClick={() => setModal("subject")}>Crear materia <Plus/></button></div>}
        <div className="stats"><div><span>Materias</span><b>{data.subjects.length}</b><small>En tu espacio</small></div><div><span>Conceptos</span><b>{data.concepts.length}</b><small>En seguimiento</small></div><div><span>Repasos pendientes</span><b>{due}</b><small>Según la programación local</small></div><div><span>Dominio orientativo</span><b>{data.concepts.length ? `${avg}%` : "—"}</b><small>No es una nota ni una prueba validada</small></div></div>
        <div className="lower"><div className="panel"><div className="section-title"><div><h2>Tus materias</h2><p>Continúa donde lo dejaste.</p></div><button className="text-btn" onClick={() => setPage("subjects")}>Ver todas →</button></div>{data.subjects.length ? data.subjects.map(s => <button className="row" key={s.id} onClick={() => { setSubjectId(s.id); setPage("subject"); }}><i style={{ background: s.color }}/><b>{s.name}</b><span>{data.concepts.filter(c => c.subjectId === s.id).length} conceptos</span><ChevronRight/></button>) : <p className="muted">Todavía no hay materias.</p>}</div><div className="panel soft"><Brain/><h2>Aprender requiere evidencias.</h2><p>Memoria, comprensión y aplicación son distintas. La app no afirmará que conoce tu método ideal sin suficientes resultados comparables.</p><button className="text-btn" onClick={() => setPage("insights")}>Cómo funciona →</button></div></div>
      </section>}
      {page === "subjects" && <section className="page"><div className="page-head"><div><label className="label">ORGANIZA TU APRENDIZAJE</label><h1>Materias</h1><p>Materiales, conceptos y sesiones en un solo lugar.</p></div><button className="primary" onClick={() => setModal("subject")}><Plus/>Nueva materia</button></div><div className="search"><Search/><input value={query} onChange={e => setQuery(e.target.value)} placeholder="Buscar materia…"/></div><div className="cards">{filtered.map(s => <button className="subject-card" key={s.id} onClick={() => { setSubjectId(s.id); setPage("subject"); }}><i style={{ background: s.color }}/><h3>{s.name}</h3><p>{data.concepts.filter(c => c.subjectId === s.id).length} conceptos{s.examDate ? ` · Examen ${new Date(`${s.examDate}T12:00:00`).toLocaleDateString("es-ES")}` : ""}</p><ChevronRight/></button>)}</div>{!filtered.length && <div className="empty"><BookOpen/><h3>Empieza por una materia</h3><p>Crea una materia para organizar lo que quieres aprender.</p><button className="primary" onClick={() => setModal("subject")}>Crear materia <Plus/></button></div>}</section>}
      {page === "subject" && current && <section className="page"><button className="back" onClick={() => setPage("subjects")}>← Todas las materias</button><div className="page-head"><div><label className="label">MATERIA</label><h1>{current.name}</h1><p>{current.examDate ? `Examen: ${new Date(`${current.examDate}T12:00:00`).toLocaleDateString("es-ES")}. ` : ""}Conceptos y evidencias de aprendizaje.</p></div><button className="primary" onClick={() => setModal("concept")}><Plus/>Nuevo concepto</button></div><div className="import-row"><div><FileText/><span>Importa texto de PDF, DOCX o TXT. Revisa siempre el resultado antes de guardarlo.</span></div><label className="secondary upload-label"><Upload/>Importar documento<input type="file" accept=".pdf,.docx,.txt,.md" onChange={importFile} hidden/></label></div>{importMessage && <p className="import-message">{importMessage}</p>}<div className="panel"><div className="section-title"><div><h2>Conceptos</h2><p>Las respuestas se autoevalúan; no hay corrección semántica automática.</p></div></div>{concepts.map(c => <div className="concept" key={c.id}><div className="tile"><Layers3/></div><div className="grow"><h3>{c.title}</h3><p>{c.explanation}</p>{c.source && <small>Fuente: {c.source}</small>}<div className="bar"><i style={{ width: `${c.mastery * 100}%` }}/></div><small>{c.reviewCount} repasos · Próximo: {Date.parse(c.nextReviewAt) <= Date.now() ? "pendiente" : new Date(c.nextReviewAt).toLocaleDateString("es-ES")}</small></div><b>{Math.round(c.mastery * 100)}%</b><button className="text-btn" onClick={() => begin(c)}>Practicar →</button><button className="icon-btn" title="Eliminar concepto" aria-label={`Eliminar ${c.title}`} onClick={() => deleteConcept(c)}><Trash2/></button></div>)}{!concepts.length && <div className="empty"><Layers3/><h3>Aún no hay conceptos</h3><p>Añade una explicación de referencia o importa un documento.</p><button className="primary" onClick={() => setModal("concept")}>Crear concepto <Plus/></button></div>}</div></section>}
      {page === "study" && active && <section className="page study-page"><button className="back" onClick={() => setPage("subject")}>← Volver a la materia</button><div className="study-card"><label className="label">SESIÓN DE ESTUDIO</label><div className="mode-tabs">{(["recall", "explain", "apply"] as PracticeMode[]).map(m => <button key={m} className={mode === m ? "chosen" : ""} onClick={() => { setMode(m); setRevealed(false); setFeedback(""); setAnswer(""); }}>{modeLabels[m]}</button>)}</div><h1>{mode === "recall" ? `Sin mirar tus apuntes, ¿qué recuerdas sobre ${active.title}?` : mode === "explain" ? `Explica ${active.title} con tus propias palabras.` : `¿Cómo aplicarías lo que sabes sobre ${active.title} a un ejemplo nuevo?`}</h1><p>Escribe primero tu respuesta. Después consulta la referencia y evalúa con sinceridad cómo te ha ido.</p><textarea rows={6} value={answer} onChange={e => setAnswer(e.target.value)} disabled={revealed || !!feedback} placeholder="Escribe tu respuesta antes de ver la referencia…"/>{!revealed && !feedback && <button className="primary" onClick={() => setRevealed(true)} disabled={!answer.trim()}>Ver referencia <ChevronRight/></button>}{revealed && !feedback && <div className="feedback"><b>Referencia guardada</b><p>{active.explanation}</p>{active.source && <small>Fuente: {active.source}</small>}<p>¿Cómo ha sido tu respuesta?</p><div className="evidence-options"><button onClick={() => record("remembered")}>Lo recordaba</button><button onClick={() => record("partial")}>Una parte</button><button onClick={() => record("forgotten")}>No lo recordaba</button></div><div className="confidence"><span>Seguridad en tu respuesta</span>{[1,2,3,4,5].map(n => <button key={n} className={confidence === n ? "chosen" : ""} onClick={() => setConfidence(n)}>{n}</button>)}</div></div>}{feedback && <div className="feedback"><b><Check/> Sesión registrada: {evidenceLabels[feedback]}</b><p>Referencia: {active.explanation}</p><p>Próximo repaso: {new Date(data.concepts.find(c => c.id === active.id)?.nextReviewAt ?? Date.now()).toLocaleDateString("es-ES")}.</p><small>La programación es una heurística sencilla, no FSRS ni una predicción clínica o académica validada.</small><div className="actions"><button className="primary" onClick={() => { const nextConcept = recommend(data); if (nextConcept && nextConcept.id !== active.id) begin(nextConcept); else setPage("home"); }}>Siguiente paso <ChevronRight/></button><button className="secondary" onClick={() => setPage("home")}>Terminar</button></div></div>}</div></section>}
      {page === "insights" && <section className="page"><label className="label">EVIDENCIAS, NO ETIQUETAS</label><h1>Cómo aprendo</h1><p className="intro">El sistema debe descubrir qué métodos ayudan en cada materia y tipo de contenido, sin asumirlo de antemano.</p><div className="notice"><Brain/><p><b>Lo que sabemos:</b> {data.responses.length ? `hay ${data.responses.length} autoevaluaciones registradas.` : "todavía no hay respuestas registradas."} Esto no basta para declarar que un método sea superior.</p></div><div className="cards three">{[["Memoria", "¿Puedes recuperar información sin verla?"], ["Comprensión", "¿Puedes explicarla con tus palabras?"], ["Aplicación", "¿Puedes usarla en una situación nueva?"]].map(([t, p]) => <div className="panel" key={t}><h2>{t}</h2><p>{p}</p><small>{data.responses.filter(r => r.mode === (t === "Memoria" ? "recall" : t === "Comprensión" ? "explain" : "apply")).length} sesiones registradas</small></div>)}</div><div className="notice"><ShieldCheck/><p>La app aún no mide retención demorada, no usa un modelo de IA y no dispone de datos suficientes para identificar un perfil de aprendizaje fiable.</p></div><div className="panel"><h2>Datos y privacidad</h2><p>En esta versión los datos permanecen en el almacenamiento del navegador. No se envían a un servidor, pero pueden perderse al borrar los datos del navegador.</p><button className="primary" onClick={() => setPage("data")}>Gestionar datos <ChevronRight/></button></div></section>}
      {page === "data" && <section className="page"><label className="label">CONFIGURACIÓN</label><h1>Datos y respaldo</h1><div className="panel"><h2>Exportar datos</h2><p>Guarda materias, conceptos, programación e historial en un archivo JSON.</p><button className="primary" onClick={downloadBackup}><Download/> Descargar respaldo</button></div><div className="panel"><h2>Restaurar respaldo</h2><p>Reemplaza los datos actuales por los de un archivo exportado anteriormente.</p><label className="secondary upload-label"><Upload/>Seleccionar archivo JSON<input type="file" accept="application/json,.json" onChange={restoreBackup} hidden/></label></div><div className="panel"><h2>Borrar todos los datos</h2><p>Esta acción no se puede deshacer. Exporta primero un respaldo si quieres conservar tus datos.</p><button className="danger" onClick={() => { if (confirm("¿Borrar todas las materias, conceptos y respuestas de este navegador?")) { setData(empty()); setPage("home"); } }}><Trash2/>Borrar datos locales</button></div><div className="notice"><ShieldCheck/><p>Esta versión no incluye cuentas, sincronización en la nube, almacenamiento de servidor ni políticas multiusuario. No introduzcas datos sensibles.</p></div></section>}
    </main>
    <nav className="mobile-nav"><button onClick={() => setPage("home")}><Home/>Inicio</button><button onClick={() => setPage("subjects")}><BookOpen/>Materias</button><button onClick={() => setPage("insights")}><Brain/>Cómo aprendo</button><button onClick={() => setPage("data")}><ShieldCheck/>Datos</button></nav>
    {modal && <div className="backdrop" onClick={e => { if (e.target === e.currentTarget) setModal(""); }}><div className="modal"><button className="close" onClick={() => setModal("")} aria-label="Cerrar"><X/></button>{modal === "subject" ? <><label className="label">ORGANIZACIÓN</label><h2>Nueva materia</h2><p>Empieza con una asignatura que estés estudiando.</p><label>Nombre<input autoFocus value={name} onChange={e => setName(e.target.value)} onKeyDown={e => e.key === "Enter" && addSubject()} placeholder="Ej. Biología"/></label><label>Fecha del examen (opcional)<input type="date" value={examDate} onChange={e => setExamDate(e.target.value)}/></label><button className="primary full" onClick={addSubject} disabled={!name.trim()}>Crear materia <Plus/></button></> : <><label className="label">CONTENIDO</label><h2>Nuevo concepto</h2><p>Define una idea concreta y una explicación de referencia. Revisa cualquier texto importado antes de guardarlo.</p><label>Nombre<input value={title} onChange={e => setTitle(e.target.value)} placeholder="Ej. La fotosíntesis"/></label><label>Explicación de referencia<textarea rows={5} value={explanation} onChange={e => setExplanation(e.target.value)} placeholder="Explicación fiable del concepto…"/></label><label>Fuente o fragmento original (opcional)<textarea rows={2} value={source} onChange={e => setSource(e.target.value)} placeholder="Página, título o fragmento del material…"/></label><button className="primary full" onClick={addConcept} disabled={!title.trim() || !explanation.trim()}>Guardar concepto <Check/></button></>}</div></div>}
  </div>;
}
