export type Evidence = "remembered" | "partial" | "forgotten" | "skipped";
export type PracticeMode = "recall" | "explain" | "apply";
export type Subject = { id: string; name: string; color: string; examDate?: string; createdAt: string };
export type Concept = {
  id: string; subjectId: string; title: string; explanation: string; source?: string;
  mastery: number; createdAt: string; nextReviewAt: string; intervalDays: number;
  lastReviewedAt?: string; reviewCount: number;
};
export type Response = {
  id: string; conceptId: string; subjectId: string; mode: PracticeMode; answer: string;
  evidence: Evidence; confidence: number; createdAt: string; dueBefore?: string;
};
export type Data = { schemaVersion: 2; subjects: Subject[]; concepts: Concept[]; responses: Response[] };
export const STORAGE_KEY = "forma-learning-data-v2";
export const LEGACY_STORAGE_KEY = "forma-learning-data-v1";
export const empty = (): Data => ({ schemaVersion: 2, subjects: [], concepts: [], responses: [] });
const clamp = (n: number, min: number, max: number) => Math.max(min, Math.min(max, n));
const validDate = (v: unknown): v is string => typeof v === "string" && Number.isFinite(Date.parse(v));

export function normalizeData(input: unknown): Data {
  if (!input || typeof input !== "object") return empty();
  const raw = input as Partial<Data>;
  const subjects = Array.isArray(raw.subjects) ? raw.subjects.filter((x): x is Subject => !!x && typeof x.id === "string" && typeof x.name === "string").map(s => ({ ...s, createdAt: validDate(s.createdAt) ? s.createdAt : new Date().toISOString() })) : [];
  const subjectIds = new Set(subjects.map(s => s.id));
  const concepts = Array.isArray(raw.concepts) ? raw.concepts.filter((x): x is Concept => !!x && typeof x.id === "string" && typeof x.subjectId === "string" && subjectIds.has(x.subjectId) && typeof x.title === "string" && typeof x.explanation === "string").map(c => ({ ...c, mastery: clamp(Number(c.mastery) || 0, 0, 1), intervalDays: Math.max(0, Number(c.intervalDays) || 0), reviewCount: Math.max(0, Number(c.reviewCount) || 0), createdAt: validDate(c.createdAt) ? c.createdAt : new Date().toISOString(), nextReviewAt: validDate(c.nextReviewAt) ? c.nextReviewAt : new Date().toISOString() })) : [];
  const conceptIds = new Set(concepts.map(c => c.id));
  const responses = Array.isArray(raw.responses) ? raw.responses.filter((x): x is Response => !!x && typeof x.id === "string" && typeof x.conceptId === "string" && conceptIds.has(x.conceptId) && validDate(x.createdAt) && ["remembered", "partial", "forgotten", "skipped"].includes(String(x.evidence))).map(r => ({ ...r, confidence: clamp(Number(r.confidence) || 3, 1, 5), mode: ["recall", "explain", "apply"].includes(String(r.mode)) ? r.mode : "recall" })) : [];
  return { schemaVersion: 2, subjects, concepts, responses };
}
export function load(): Data {
  try {
    const current = localStorage.getItem(STORAGE_KEY);
    if (current) return normalizeData(JSON.parse(current));
    const legacy = localStorage.getItem(LEGACY_STORAGE_KEY);
    if (legacy) {
      const old = JSON.parse(legacy) as { subjects?: Subject[]; concepts?: Partial<Concept>[]; responses?: Partial<Response>[] };
      return normalizeData({ schemaVersion: 2, subjects: old.subjects ?? [], concepts: (old.concepts ?? []).map(c => ({ ...c, nextReviewAt: c.nextReviewAt ?? new Date().toISOString(), intervalDays: 0, reviewCount: 0 })), responses: [] });
    }
  } catch { /* damaged browser storage: start safely empty */ }
  return empty();
}
export function save(data: Data): void { localStorage.setItem(STORAGE_KEY, JSON.stringify(data)); }
export function createConcept(input: Pick<Concept, "subjectId" | "title" | "explanation" | "source">, now = new Date()): Concept {
  return { id: crypto.randomUUID(), ...input, mastery: 0, createdAt: now.toISOString(), nextReviewAt: now.toISOString(), intervalDays: 0, reviewCount: 0 };
}
export function scheduleReview(concept: Concept, evidence: Evidence, now = new Date()): Concept {
  const factors: Record<Evidence, number> = { remembered: 2.2, partial: 1.35, forgotten: 0.35, skipped: 0.8 };
  const interval = concept.intervalDays === 0 ? 1 : evidence === "forgotten" ? 1 : Math.max(1, Math.round(concept.intervalDays * factors[evidence]));
  const delta: Record<Evidence, number> = { remembered: 0.12, partial: 0.04, forgotten: -0.12, skipped: 0 };
  const due = new Date(now); due.setDate(due.getDate() + interval);
  return { ...concept, mastery: clamp(Number((concept.mastery + delta[evidence]).toFixed(3)), 0, 1), intervalDays: interval, nextReviewAt: due.toISOString(), lastReviewedAt: now.toISOString(), reviewCount: concept.reviewCount + 1 };
}
export function recommend(data: Data, subjectId?: string, now = new Date()): Concept | undefined {
  const pool = data.concepts.filter(c => !subjectId || c.subjectId === subjectId);
  return [...pool].sort((a, b) => {
    const aDue = Date.parse(a.nextReviewAt) <= now.getTime(), bDue = Date.parse(b.nextReviewAt) <= now.getTime();
    if (aDue !== bDue) return aDue ? -1 : 1;
    if (a.mastery !== b.mastery) return a.mastery - b.mastery;
    return Date.parse(a.nextReviewAt) - Date.parse(b.nextReviewAt);
  })[0];
}
export function dueCount(data: Data, now = new Date()): number { return data.concepts.filter(c => Date.parse(c.nextReviewAt) <= now.getTime()).length; }
export function exportData(data: Data): string { return JSON.stringify({ ...data, exportedAt: new Date().toISOString() }, null, 2); }
