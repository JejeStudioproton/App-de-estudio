# FORMA — aprendizaje personal

Aplicación web progresiva (PWA) para organizar materias, guardar conceptos, practicar recuperación activa y programar repasos a partir de autoevaluaciones.

## Funciones incluidas

- Interfaz adaptable a móvil y iPad, con navegación de escritorio y móvil.
- Materias con fecha de examen opcional y conceptos con explicación y referencia.
- Importación de texto desde PDF con texto seleccionable, DOCX, TXT y Markdown. El contenido extraído se presenta como borrador editable; no se guarda hasta que el usuario lo revise y confirme.
- Tres modos de práctica: recordar, explicar y aplicar.
- Autoevaluación explícita después de ver la referencia; la app no afirma que una comparación de palabras equivalga a comprensión.
- Programación local de repasos y dominio orientativo, con algoritmo sencillo y visible en su limitación (no FSRS).
- Historial de respuestas, estadísticas descriptivas y respaldo/restauración JSON.
- Service worker básico para conservar la carcasa de la app y manifest PWA.
- Migración del esquema de almacenamiento anterior.

## Ejecutar en local

Requiere Node.js 20 o posterior.

```bash
npm install
npm run dev
npm run check
npm test
npm run build
```

## Limitaciones conocidas

- No incluye autenticación, sincronización multi-dispositivo, backend ni sincronización entre usuarios.
- Los datos viven en `localStorage` de este navegador. Exporta un respaldo si quieres conservarlos.
- No incluye OCR: los PDF escaneados sin texto seleccionable no se pueden importar.
- La extracción de documentos no identifica conceptos pedagógicos automáticamente; crea un borrador de texto que debe revisarse.
- La evaluación es una autoevaluación del estudiante, no una corrección semántica por IA.
- La programación de repasos es una heurística de intervalos, no FSRS. La retención demorada aún no se mide.
- El service worker cachea la carcasa de la app; no garantiza que toda dependencia externa funcione sin conexión.
- La tipografía web puede requerir conexión. Si se desea funcionamiento completamente offline, conviene empaquetarla localmente.

## Siguiente etapa de producción

1. Añadir pruebas E2E en Safari/iPad y navegación por teclado.
2. Sustituir el programador simple por `ts-fsrs` con pruebas de migración.
3. Implementar Auth, PostgreSQL y almacenamiento privado con RLS antes de sincronizar datos.
4. Añadir proveedor de IA configurable con respuestas estructuradas, límites de coste y trazabilidad de fuentes; no guardar conceptos extraídos sin confirmación del usuario.
5. Medir retención demorada y comparar métodos por estudiante × materia × tipo de contenido, evitando conclusiones con muestras pequeñas.
6. Revisar accesibilidad, política de privacidad, manejo de errores y estrategia de recuperación de datos.
